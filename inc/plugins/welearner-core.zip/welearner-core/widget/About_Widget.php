<?php
class Welearner_About extends WP_Widget {

	public function __construct() {
		$widget_ops = array(
			'classname'                   => 'about-company',
			'customize_selective_refresh' => true,
		);
		parent::__construct( 'welearner-about-company', __( 'Welearner:: About Company','welearner-core' ), $widget_ops );
	}

	public function widget( $args, $instance ) {
		$default_title = __( 'Welearner' ,'welearner-core' );
		$title         = ( ! empty( $instance['title'] ) ) ? $instance['title'] : $default_title;
		$title 		   = apply_filters( 'widget_title', $title );
		$fb_url        = ( ! empty( $instance['fb_url'] ) ) ? $instance['fb_url'] : '#';
		$twitter_url   = ( ! empty( $instance['twitter_url'] ) ) ? $instance['twitter_url'] : '#';
		$linkedin_url  = ( ! empty( $instance['linkedin_url'] ) ) ? $instance['linkedin_url'] : '#';


	    echo $args['before_widget'];
            if ( $title ) {
                echo $args['before_title'] . $title . $args['after_title'];
            }
			
			if( $instance['desc'] ) {
				echo wpautop(wp_kses_post($instance['desc']));
			}
		?>
        <div class="social-icons">
            <ul class="list-unstyled d-flex">
                <li><a href="<?php echo esc_url($fb_url); ?>"><i class="dashicons dashicons-facebook-alt"></i></a></li>
                <li><a href="<?php echo esc_url($twitter_url); ?>"><i class="dashicons dashicons-twitter"></i></a></li>
                <li><a href="<?php echo esc_url($linkedin_url); ?>"><i class="dashicons dashicons-linkedin"></i></a></li>
            </ul>
        </div>

		<?php
		echo $args['after_widget'];
	}

	public function update( $new_instance, $old_instance ) {
		$instance                   = $old_instance;
		$instance['title']          = sanitize_text_field( $new_instance['title'] );
		$instance['desc']           = sanitize_text_field($new_instance['desc']);
		$instance['fb_url']         = sanitize_text_field( $new_instance['fb_url'] );
		$instance['twitter_url']    = sanitize_text_field( $new_instance['twitter_url'] );
		$instance['linkedin_url']   = sanitize_text_field( $new_instance['linkedin_url'] );
		return $instance;
	}

	public function form( $instance ) {
		$title          = isset( $instance['title'] ) ? esc_attr( $instance['title'] ) : '';
		$desc           = isset( $instance['desc'] ) ? esc_attr( $instance['desc'] ) : '';
		$fb_url         = isset( $instance['fb_url'] ) ? esc_url( $instance['fb_url'] ) : '';
		$twitter_url    = isset( $instance['twitter_url'] ) ? esc_url( $instance['twitter_url'] ) : '';
		$linkedin_url   = isset( $instance['fb_url'] ) ? esc_url( $instance['linkedin_url'] ) : '';
		?>
		<p>
			<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:','welearner-core' ); ?></label>
			<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo $title; ?>" />
        </p>
        
        <p>
			<label for="<?php echo $this->get_field_id( 'desc' ); ?>"><?php _e( 'Description:','welearner-core'  ); ?></label>
			<textarea class="widefat" id="<?php echo $this->get_field_id( 'desc' ); ?>" name="<?php echo $this->get_field_name( 'desc' ); ?>"><?php echo $desc; ?></textarea>
		</p>
        
        <p>
			<label for="<?php echo $this->get_field_id( 'fb_url' ); ?>"><?php _e( 'Facebook URL:','welearner-core'  ); ?></label>
			<input class="widefat" id="<?php echo $this->get_field_id( 'fb_url' ); ?>" name="<?php echo $this->get_field_name( 'fb_url' ); ?>" type="text" value="<?php echo $fb_url; ?>" />
		</p>
        
        <p>
			<label for="<?php echo $this->get_field_id( 'twitter_url' ); ?>"><?php _e( 'Twitter URL:','welearner-core'  ); ?></label>
			<input class="widefat" id="<?php echo $this->get_field_id( 'twitter_url' ); ?>" name="<?php echo $this->get_field_name( 'twitter_url' ); ?>" type="text" value="<?php echo $twitter_url; ?>" />
		</p>
        
        <p>
			<label for="<?php echo $this->get_field_id( 'linkedin_url' ); ?>"><?php _e( 'Linkedin URL:','welearner-core'  ); ?></label>
			<input class="widefat" id="<?php echo $this->get_field_id( 'linkedin_url' ); ?>" name="<?php echo $this->get_field_name( 'linkedin_url' ); ?>" type="text" value="<?php echo $linkedin_url; ?>" />
		</p>

		<?php
	}
}


add_action('widgets_init',function(){
	register_widget('Welearner_About');
});