<?php
/*
Plugin Name: Welearner Core
Description: A helper plugin for welearner theme
Version: 1.0
Author: Ahsan Habib Shaheen
Author URI: https://github.com/ahsanshaheen199
License: GPLv2 or later
Text Domain: welearner-core
*/

defined( 'ABSPATH' ) || exit;

final class Welearner_Core {
    const VERSION = '1.0';

    private function __construct() {
        $this->define_constants();
        $this->init_actions();
    }

    public static function init() {
        static $instance = false;

        if ( ! $instance ) {
            $instance = new Welearner_Core();
        }

        return $instance;
    }

    public function define_constants() {
        define( 'WELEARNERCORE_VERSION', '1.0' );
        define( 'WELEARNERCORE_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
        define( 'WELEARNERCORE_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
    }

    public function init_actions() {
        require WELEARNERCORE_PLUGIN_DIR . 'post-types/Post_Types.php';
        require WELEARNERCORE_PLUGIN_DIR . 'widget/About_Widget.php';
    }
}

function welearner_core() {
    return Welearner_Core::init();
}

welearner_core();