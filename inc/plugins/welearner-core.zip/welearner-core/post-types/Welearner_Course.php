<?php

class Welearner_Course {
    public function __construct() {
        add_action( 'init', [ $this, 'register_post_type' ] );
        add_action( 'init', [ $this, 'register_taxonomy' ] );
        add_action( 'add_meta_boxes', [$this, 'register_meta_box'] );
        add_action( 'save_post',      [$this, 'save_metabox' ], 10, 3 );
        add_action('course_topic_add_form_fields',[$this,'add_course_topic_fields'], 10, 1);
        add_action('course_topic_edit_form_fields',[$this,'edit_course_topic_fields'], 10, 2);
        add_action( 'created_term', [ $this, 'save_course_topic_fields' ], 10, 3 );
		add_action( 'edit_term', [ $this, 'save_course_topic_fields' ], 10, 3 );
        add_action( 'admin_enqueue_scripts', [$this,'course_topic_scripts'] );
    }

    public function register_post_type() {
        $labels = [
            'name'               => _x( 'Courses', 'Post Type General Name', 'welearner-core' ),
            'singular_name'      => _x( 'Course', 'Post Type Singular Name', 'welearner-core' ),
            'menu_name'          => __( 'Courses', 'welearner-core' ),
            'parent_item_colon'  => __( 'Parent Course', 'welearner-core' ),
            'all_items'          => __( 'All Courses', 'welearner-core' ),
            'view_item'          => __( 'View Course', 'welearner-core' ),
            'add_new_item'       => __( 'Add Course', 'welearner-core' ),
            'add_new'            => __( 'Add New', 'welearner-core' ),
            'edit_item'          => __( 'Edit Course', 'welearner-core' ),
            'update_item'        => __( 'Update Course', 'welearner-core' ),
            'search_items'       => __( 'Search Course', 'welearner-core' ),
            'not_found'          => __( 'Not Course found', 'welearner-core' ),
            'not_found_in_trash' => __( 'Not found in Trash', 'welearner-core' ),
        ];
        

        $args = [
            'labels'              => $labels,
            'supports'            => [ 'title', 'editor', 'thumbnail' ],
            'hierarchical'        => true,
            'public'              => true,
            'show_ui'             => true,
            'show_in_menu'        => true,
            'show_in_nav_menus'   => true,
            'show_in_admin_bar'   => true,
            'menu_position'       => 5,
            'menu_icon'           => 'dashicons-welcome-learn-more',
            'can_export'          => true,
            'has_archive'         => true,
            'exclude_from_search' => false,
            'publicly_queryable'  => true,
            'capability_type'     => 'post',
        ];

        register_post_type( 'courses', $args );
    }

    public function register_taxonomy() {
        $labels = [
            'name'                       => _x( 'Topics', 'Taxonomy General Name', 'welearner-core' ),
            'singular_name'              => _x( 'Topic', 'Taxonomy Singular Name', 'welearner-core' ),
            'menu_name'                  => __( 'Topics', 'welearner-core' ),
            'all_items'                  => __( 'All Topics', 'welearner-core' ),
            'parent_item'                => __( 'Parent Topics', 'welearner-core' ),
            'parent_item_colon'          => __( 'Parent Topics:', 'welearner-core' ),
            'new_item_name'              => __( 'New Topics', 'welearner-core' ),
            'add_new_item'               => __( 'Add New Item', 'welearner-core' ),
            'edit_item'                  => __( 'Edit Topics', 'welearner-core' ),
            'update_item'                => __( 'Update Topics', 'welearner-core' ),
            'view_item'                  => __( 'View Topics', 'welearner-core' ),
            'separate_items_with_commas' => __( 'Separate items with commas', 'welearner-core' ),
            'add_or_remove_items'        => __( 'Add or remove items', 'welearner-core' ),
            'choose_from_most_used'      => __( 'Choose from the most used', 'welearner-core' ),
            'popular_items'              => __( 'Popular Topics', 'welearner-core' ),
            'search_items'               => __( 'Search Topics', 'welearner-core' ),
            'not_found'                  => __( 'Not Found', 'welearner-core' ),
            'no_terms'                   => __( 'No items', 'welearner-core' ),
            'items_list'                 => __( 'Topics list', 'welearner-core' ),
            'items_list_navigation'      => __( 'Topics list navigation', 'welearner-core' ),
        ];

        $args = [
            'labels'            => $labels,
            'hierarchical'      => true,
            'public'            => true,
            'show_ui'           => true,
            'show_admin_column' => true,
            'show_in_nav_menus' => true,
        ];

        register_taxonomy( 'course_topic', [ 'courses' ], $args );
    }

    public function register_meta_box() {
        add_meta_box( 'welearner-course-meta-info', __( 'Course Meta Info', 'welearner-core' ), [$this, 'course_meta_box'], 'courses' );
    }

    public function course_meta_box($post) {
        $regular_price = get_post_meta( $post->ID, '_welearner_course_regular_price', true);
        $sale_price    = get_post_meta( $post->ID, '_welearner_course_sale_price', true);
        $course_author = get_post_meta( $post->ID, '_welearner_course_author', true);
        wp_nonce_field( 'welearner_course_meta_action', 'welearner_course_meta_nonce' );
        ?>

        <div class="weleaner-meta-wrapper">
            <label for="welearner_course_regular_price"><?php _e('Regular Price','welearner-core'); ?></label>
            <input id="welearner_course_regular_price" name="welearner_course_regular_price" class="regular-text" type="text" value="<?php echo esc_attr($sale_price); ?>">
        </div>

        <div class="weleaner-meta-wrapper">
            <label for="welearner_course_sale_price"><?php _e('Sale Price','welearner-core'); ?></label>
            <input id="welearner_course_sale_price" name="welearner_course_sale_price" class="regular-text" type="text" value="<?php echo esc_attr($regular_price); ?>">
        </div>

        <div class="weleaner-meta-wrapper">
            <label for="welearner_course_author"><?php _e('Author','welearner-core'); ?></label>
            <select id="welearner_course_author" name="welearner_course_author" class="regular-text">
                <option value=""><?php _e('Select Author','welearner-core'); ?></option>
                <?php 
                    foreach($this->get_teacher_list() as $index => $value) {
                        echo '<option '.selected($course_author,$index,false).' value="'.esc_attr($index).'">'.esc_html($value).'</option>';
                    }
                ?>
            </select>
        </div>

        <style type="text/css">
            .weleaner-meta-wrapper {
                display: flex;
                align-items: center;
                padding: 30px 0;
                border-bottom: 1px solid #e9e9e9;
            }

            .weleaner-meta-wrapper label{
                flex-basis: 150px;
            }

            .weleaner-meta-wrapper input{
                flex-basis: 350px;
            }
        </style>
    <?php 
    }

    public function save_metabox($post_id,$post, $update) {

        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
            return $post_id;
        }

        if ( wp_is_post_revision( $post_id ) || wp_is_post_autosave( $post_id ) || 'courses' !== $post->post_type ) {
			return $post_id;
		}

        if ( ! isset( $_POST['welearner_course_meta_nonce'] ) || ! wp_verify_nonce( $_POST['welearner_course_meta_nonce'], 'welearner_course_meta_action' ) ) {
            return;
        }

        if (isset($_POST['welearner_course_regular_price'])) {
			$regular_price = (int)sanitize_text_field( $_POST['welearner_course_regular_price'] );
			if ( $regular_price ) {
				update_post_meta( $post_id, '_welearner_course_regular_price', $regular_price );
			}
        }
        
        if (isset($_POST['welearner_course_sale_price'])) {
			$sale_price = (int)sanitize_text_field( $_POST['welearner_course_sale_price'] );
			if ( $sale_price ) {
				update_post_meta( $post_id, '_welearner_course_sale_price', $sale_price );
			}
        }
        
        if (isset($_POST['welearner_course_author'])) {
			$course_author = sanitize_text_field( $_POST['welearner_course_author'] );
			if ( $course_author ) {
				update_post_meta( $post_id, '_welearner_course_author', $course_author );
			}
        }
        
        if( ! get_post_meta($post_id, '_welearner_course_avg_rating', 0) ) {
            update_post_meta( $post_id, '_welearner_course_avg_rating', 0 );
        }
    }

    public function add_course_topic_fields($taxonomy) {
        ?>
        <div class="form-field term-color-wrap">
            <label for="course_topic_color"><?php esc_html_e( 'Color', 'welearner-core' ); ?></label>
            <input class="course_topic_color" type="text" name="course_topic_color" />
        </div>
        <div class="form-field term-color-wrap">
            <label for="course_topic_bg_color"><?php esc_html_e( 'Background Color', 'welearner-core' ); ?></label>
            <input class="course_topic_bg_color" type="text" name="course_topic_bg_color" />
        </div>

        <div class="form-field term-thumbnail-wrap">
            <label for="course_topic_thumbnail"><?php esc_html_e( 'Thumbnail', 'welearner-core' ); ?></label>
            <div id="course_topic_thumbnail" style="float: left; margin-right: 10px;"><img src="https://place-hold.it/60x60/#e9e9e" width="60px" height="60px" /></div>
            <div style="line-height: 60px;">
                <input type="hidden" id="course_topic_thumbnail_id" name="course_topic_thumbnail_id" value="" />
                <button type="button" class="upload_course_topic_button button"><?php esc_html_e( 'Upload/Add image', 'welearner-core' ); ?></button>
                <button type="button" class="remove_course_topic_button button"><?php esc_html_e( 'Remove image', 'welearner-core' ); ?></button>
            </div>
        </div>
    <?php 
    }

    public function edit_course_topic_fields($term,$taxonomy) {
        $color = get_term_meta( $term->term_id, '_course_topic_color', true );
        $bgcolor = get_term_meta( $term->term_id, '_course_topic_bg_color', true );
        $thumbnail_id = absint( get_term_meta( $term->term_id, '_course_topic_thumbnail_id', true ) );
        if ( $thumbnail_id ) {
			$image = wp_get_attachment_url( $thumbnail_id );
		} else {
			$image = "https://place-hold.it/60x60/#e9e9e";
		}
        ?>
        <tr class="form-field term-color-wrap">
            <th scope="row" valign="top"><label for="course_topic_color"><?php esc_html_e( 'Color', 'welearner-core' ); ?></label></th>
            <td><input class="course_topic_color" type="text" name="course_topic_color" value="<?php echo esc_attr($color); ?>" /></td>
        </tr>
        <tr class="form-field term-color-wrap">
            <th scope="row" valign="top"><label for="course_topic_bg_color"><?php esc_html_e( 'Background Color', 'welearner-core' ); ?></label></th>
            <td><input class="course_topic_bg_color" type="text" name="course_topic_bg_color" value="<?php echo esc_attr($bgcolor); ?>" /></td>
        </tr>

        <tr class="form-field term-thumbnail-wrap">
            <th scope="row" valign="top"><label for="course_topic_thumbnail"><?php esc_html_e( 'Thumbnail', 'welearner-core' ); ?></label></th>
            <td>
                <div id="course_topic_thumbnail" style="float: left; margin-right: 10px;"><img src="<?php echo esc_url($image);  ?>" width="60px" height="60px" /></div>
                <div style="line-height: 60px;">
                    <input type="hidden" id="course_topic_thumbnail_id" name="course_topic_thumbnail_id" value="<?php echo esc_attr($thumbnail_id); ?>" />
                    <button type="button" class="upload_course_topic_button button"><?php esc_html_e( 'Upload/Add image', 'welearner-core' ); ?></button>
                    <button type="button" class="remove_course_topic_button button"><?php esc_html_e( 'Remove image', 'welearner-core' ); ?></button>
                </div>
            </td>
            
        </tr>
    <?php 
    }

    public function course_topic_scripts( $hook_suffix ) {
        $screen = get_current_screen();
        if( ( $hook_suffix != 'edit-tags.php' || $hook_suffix != 'term.php') && $screen->taxonomy != 'course_topic' ) {
            return;
        }
        wp_enqueue_style( 'wp-color-picker' );
        wp_enqueue_media();
        wp_enqueue_script( 'course-script', WELEARNERCORE_PLUGIN_URL . 'assets/js/course.js', array( 'wp-color-picker' ), false, true );
    }

    public function save_course_topic_fields($term_id, $tt_id = '', $taxonomy = '') {
        if ( isset( $_POST['course_topic_thumbnail_id'] ) && 'course_topic' === $taxonomy ) {
			update_term_meta( $term_id, '_course_topic_thumbnail_id', absint( $_POST['course_topic_thumbnail_id'] ) );
        }
        
        if ( isset( $_POST['course_topic_color'] ) && 'course_topic' === $taxonomy ) {
			update_term_meta( $term_id, '_course_topic_color',$_POST['course_topic_color'] );
		}
        
        if ( isset( $_POST['course_topic_bg_color'] ) && 'course_topic' === $taxonomy ) {
			update_term_meta( $term_id, '_course_topic_bg_color',$_POST['course_topic_bg_color'] );
		}
    }

    public function get_teacher_list() {
        $postteachers = get_posts([
            'post_type'         => 'teachers',
            'posts_per_page'    => -1,
            'post_status'       => 'publish'
        ]);

        $teachers = [];
        foreach( $postteachers as $singleteacher ) {
            $teachers[$singleteacher->ID] = $singleteacher->post_title;
        }

        return $teachers;
    }
}

$courses = new Welearner_Course();