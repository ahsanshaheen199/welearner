<?php

class Post_Types {
    public function __construct() {
        $this->init_class();    
    }

    public function init_class() {
        require WELEARNERCORE_PLUGIN_DIR . 'post-types/Welearner_Course.php';
        require WELEARNERCORE_PLUGIN_DIR . 'post-types/Welearner_Teacher.php';
        require WELEARNERCORE_PLUGIN_DIR . 'post-types/Welearner_Testimonial.php';
    }
}

$post_types = new Post_Types();