<?php

class Welearner_Testimonial {
    public function __construct() {
        add_action( 'init', [ $this, 'register_post_type' ] );
        add_action( 'add_meta_boxes', [$this, 'register_meta_box'] );
        add_action( 'save_post',      [$this, 'save_metabox' ], 10, 3 );
    }

    public function register_post_type() {
        $labels = [
            'name'                  => _x( 'Testimonials', 'Post Type General Name', 'welearner-core' ),
            'singular_name'         => _x( 'Testimonial', 'Post Type Singular Name', 'welearner-core' ),
            'menu_name'             => __( 'Testimonials', 'welearner-core' ),
            'parent_item_colon'     => __( 'Parent Testimonial', 'welearner-core' ),
            'all_items'             => __( 'All Testimonials', 'welearner-core' ),
            'view_item'             => __( 'View Testimonial', 'welearner-core' ),
            'add_new_item'          => __( 'Add Testimonial', 'welearner-core' ),
            'add_new'               => __( 'Add New', 'welearner-core' ),
            'edit_item'             => __( 'Edit Testimonial', 'welearner-core' ),
            'update_item'           => __( 'Update Testimonial', 'welearner-core' ),
            'search_items'          => __( 'Search Testimonial', 'welearner-core' ),
            'not_found'             => __( 'Not Testimonial found', 'welearner-core' ),
            'not_found_in_trash'    => __( 'Not found in Trash', 'welearner-core' ),
            'featured_image'        => _x( 'Reviewer Image', 'Overrides the "Featured Image" phrase for this post type.', 'welearner-core' ),
            'set_featured_image'    => _x( 'Set Reviewer image', 'Overrides the "Set featured image" phrase for this post type.', 'welearner-core' ),
            'remove_featured_image' => _x( 'Remove Reviewer image', 'Overrides the "Remove featured image" phrase for this post type.', 'welearner-core' ),
        ];
        

        $args = [
            'labels'              => $labels,
            'supports'            => [ 'title', 'thumbnail' ],
            'hierarchical'        => true,
            'public'              => true,
            'show_ui'             => true,
            'show_in_menu'        => true,
            'show_in_nav_menus'   => true,
            'show_in_admin_bar'   => true,
            'menu_position'       => 5,
            'menu_icon'           => 'dashicons-testimonial',
            'can_export'          => true,
            'has_archive'         => true,
            'exclude_from_search' => false,
            'publicly_queryable'  => true,
            'capability_type'     => 'post',
        ];

        register_post_type( 'testimonials', $args );
    }

    public function register_meta_box() {
        add_meta_box( 'welearner-reviewer-meta-info', __( 'Reviewer Info', 'welearner-core' ), [$this, 'reviewer_meta_box'], 'testimonials' );
    }

    public function reviewer_meta_box($post) {
        $description   = get_post_meta( $post->ID, '_welearner_testimonial_desc', true);
        $subdescription   = get_post_meta( $post->ID, '_welearner_testimonial_subdesc', true);
        $designation   = get_post_meta( $post->ID, '_welearner_reviewer_designation', true);
        wp_nonce_field( 'welearner_reviewer_meta_action', 'welearner_reviewer_meta_nonce' );
        ?>

        <div class="weleaner-meta-wrapper">
            <label for="welearner_reviewer_designation"><?php _e('Designation','welearner-core'); ?></label>
            <input id="welearner_reviewer_designation" name="welearner_reviewer_designation" class="regular-text" type="text" value="<?php echo esc_attr($designation); ?>">
        </div>

        <div class="weleaner-meta-wrapper">
            <label for="welearner_testimonial_desc"><?php _e('Content','welearner-core'); ?></label>
            <textarea id="welearner_testimonial_desc" name="welearner_testimonial_desc" class="regular-text"><?php echo wp_kses_post($description); ?></textarea>
        </div>

        <div class="weleaner-meta-wrapper">
            <label for="welearner_testimonial_subdesc"><?php _e('Additional Content','welearner-core'); ?></label>
            <textarea id="welearner_testimonial_subdesc" name="welearner_testimonial_subdesc" class="regular-text"><?php echo wp_kses_post($subdescription); ?></textarea>
        </div>


        <style type="text/css">
            .weleaner-meta-wrapper {
                display: flex;
                align-items: center;
                padding: 30px 0;
                border-bottom: 1px solid #e9e9e9;
            }

            .weleaner-meta-wrapper label{
                flex-basis: 150px;
            }

            .weleaner-meta-wrapper input{
                flex-basis: 350px;
            }
        </style>
    <?php 
    }

    public function save_metabox( $post_id, $post, $update ) {

        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
            return $post_id;
        }

        if ( wp_is_post_revision( $post_id ) || wp_is_post_autosave( $post_id ) || 'testimonials' !== $post->post_type ) {
			return $post_id;
        }
        

        if ( ! isset( $_POST['welearner_reviewer_meta_nonce'] ) || ! wp_verify_nonce( $_POST['welearner_reviewer_meta_nonce'], 'welearner_reviewer_meta_action' ) ) {
            return;
        }

        if ( isset( $_POST['welearner_testimonial_desc'] ) ) {
			$description = sanitize_text_field( $_POST['welearner_testimonial_desc'] );
			if ( $description ) {
				update_post_meta( $post_id, '_welearner_testimonial_desc', $description );
			}
        }

        if ( isset( $_POST['welearner_testimonial_subdesc'] ) ) {
			$subdescription = sanitize_text_field( $_POST['welearner_testimonial_subdesc'] );
			if ( $subdescription ) {
				update_post_meta( $post_id, '_welearner_testimonial_subdesc', $subdescription );
			}
        }

        if ( isset( $_POST['welearner_reviewer_designation'] ) ) {
			$designation = sanitize_text_field( $_POST['welearner_reviewer_designation'] );
			if ( $designation ) {
				update_post_meta( $post_id, '_welearner_reviewer_designation', $designation );
			}
        }
    }

}

$testimonial = new Welearner_Testimonial();