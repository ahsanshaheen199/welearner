<?php

class Welearner_Teacher {
    public function __construct() {
        add_action( 'init', [ $this, 'register_post_type' ] );
        add_action( 'add_meta_boxes', [$this, 'register_meta_box'] );
        add_action( 'save_post',      [$this, 'save_metabox' ], 10, 3 );
        add_action( 'admin_enqueue_scripts', [$this,'teacher_admin_scripts'] );
    }

    public function register_post_type() {
        $labels = [
            'name'                  => _x( 'Teachers', 'Post Type General Name', 'welearner-core' ),
            'singular_name'         => _x( 'Teacher', 'Post Type Singular Name', 'welearner-core' ),
            'menu_name'             => __( 'Teachers', 'welearner-core' ),
            'parent_item_colon'     => __( 'Parent Teacher', 'welearner-core' ),
            'all_items'             => __( 'All Teachers', 'welearner-core' ),
            'view_item'             => __( 'View Teacher', 'welearner-core' ),
            'add_new_item'          => __( 'Add Teacher', 'welearner-core' ),
            'add_new'               => __( 'Add New', 'welearner-core' ),
            'edit_item'             => __( 'Edit Teacher', 'welearner-core' ),
            'update_item'           => __( 'Update Teacher', 'welearner-core' ),
            'search_items'          => __( 'Search Teacher', 'welearner-core' ),
            'not_found'             => __( 'Not Teacher found', 'welearner-core' ),
            'not_found_in_trash'    => __( 'Not found in Trash', 'welearner-core' ),
            'featured_image'        => _x( 'Teacher Image', 'Overrides the "Featured Image" phrase for this post type.', 'welearner-core' ),
            'set_featured_image'    => _x( 'Set teacher image', 'Overrides the "Set featured image" phrase for this post type.', 'welearner-core' ),
            'remove_featured_image' => _x( 'Remove teacher image', 'Overrides the "Remove featured image" phrase for this post type.', 'welearner-core' ),
        ];
        

        $args = [
            'labels'              => $labels,
            'supports'            => [ 'title', 'thumbnail' ],
            'hierarchical'        => true,
            'public'              => true,
            'show_ui'             => true,
            'show_in_menu'        => true,
            'show_in_nav_menus'   => true,
            'show_in_admin_bar'   => true,
            'menu_position'       => 5,
            'menu_icon'           => 'dashicons-businessperson',
            'can_export'          => true,
            'has_archive'         => true,
            'exclude_from_search' => false,
            'publicly_queryable'  => true,
            'capability_type'     => 'post',
        ];

        register_post_type( 'teachers', $args );
    }

    public function register_meta_box() {
        add_meta_box( 'welearner-teacher-meta-info', __( 'Teacher Meta Info', 'welearner-core' ), [$this, 'teacher_meta_box'], 'teachers' );
    }

    public function teacher_meta_box($post) {
        $designation   = get_post_meta( $post->ID, '_welearner_teacher_designation', true);
        $fb_url        = get_post_meta( $post->ID, '_welearner_teacher_fb_url', true);
        $twitter_url   = get_post_meta( $post->ID, '_welearner_teacher_twitter_url', true);
        $linkedin_url  = get_post_meta( $post->ID, '_welearner_teacher_linkedin_url', true);
        $thumb_bg_color  = get_post_meta( $post->ID, '_welearner_teacher_thumbnail_bg_color', true) ?? '#e9e9e9';
        wp_nonce_field( 'welearner_teacher_meta_action', 'welearner_teacher_meta_nonce' );
        ?>

        <div class="weleaner-meta-wrapper">
            <label for="welearner_teacher_designation"><?php _e('Designation','welearner-core'); ?></label>
            <input id="welearner_teacher_designation" name="welearner_teacher_designation" class="regular-text" type="text" value="<?php echo esc_attr($designation); ?>">
        </div>

        <div class="weleaner-meta-wrapper">
            <label for="welearner_teacher_fb_url"><?php _e('Facebook URL','welearner-core'); ?></label>
            <input id="welearner_teacher_fb_url" name="welearner_teacher_fb_url" class="regular-text" type="text" value="<?php echo esc_url($fb_url); ?>">
        </div>

        <div class="weleaner-meta-wrapper">
            <label for="welearner_teacher_linkedin_url"><?php _e('linkedin URL','welearner-core'); ?></label>
            <input id="welearner_teacher_linkedin_url" name="welearner_teacher_linkedin_url" class="regular-text" type="text" value="<?php echo esc_url($linkedin_url); ?>">
        </div>

        <div class="weleaner-meta-wrapper">
            <label for="welearner_teacher_twitter_url"><?php _e('Twitter URL','welearner-core'); ?></label>
            <input id="welearner_teacher_twitter_url" name="welearner_teacher_twitter_url" class="regular-text" type="text" value="<?php echo esc_url($twitter_url); ?>">
        </div>

        <div class="weleaner-meta-wrapper">
            <label for="welearner_teacher_thumbnail_bg_color"><?php esc_html_e( 'Thumbnail Background Color', 'welearner-core' ); ?></label>
            <input id="welearner_teacher_thumbnail_bg_color" class="welearner_teacher_thumbnail_bg_color" type="text" name="welearner_teacher_thumbnail_bg_color" value="<?php echo esc_attr($thumb_bg_color); ?>" />
        </div>

        <style type="text/css">
            .weleaner-meta-wrapper {
                display: flex;
                align-items: center;
                padding: 30px 0;
                border-bottom: 1px solid #e9e9e9;
            }

            .weleaner-meta-wrapper label{
                flex-basis: 150px;
            }

            .weleaner-meta-wrapper input{
                flex-basis: 350px;
            }
        </style>
    <?php 
    }

    public function save_metabox($post_id,$post, $update) {

        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
            return $post_id;
        }

        if ( wp_is_post_revision( $post_id ) || wp_is_post_autosave( $post_id ) || 'teachers' !== $post->post_type ) {
			return $post_id;
        }
        

        if ( ! isset( $_POST['welearner_teacher_meta_nonce'] ) || ! wp_verify_nonce( $_POST['welearner_teacher_meta_nonce'], 'welearner_teacher_meta_action' ) ) {
            return;
        }

        if (isset($_POST['welearner_teacher_designation'])) {
			$designation = sanitize_text_field( $_POST['welearner_teacher_designation'] );
			if ( $designation ) {
				update_post_meta( $post_id, '_welearner_teacher_designation', $designation );
			}
        }

        if (isset($_POST['welearner_teacher_fb_url'])) {
			$fb_url = sanitize_text_field( $_POST['welearner_teacher_fb_url'] );
			if ( $fb_url ) {
				update_post_meta( $post_id, '_welearner_teacher_fb_url', $fb_url );
			}
        }

        if (isset($_POST['welearner_teacher_linkedin_url'])) {
			$linkedin_url = sanitize_text_field( $_POST['welearner_teacher_linkedin_url'] );
			if ( $linkedin_url ) {
				update_post_meta( $post_id, '_welearner_teacher_linkedin_url', $linkedin_url );
			}
        }

        if (isset($_POST['welearner_teacher_twitter_url'])) {
			$twitter_url = sanitize_text_field( $_POST['welearner_teacher_twitter_url'] );
			if ( $twitter_url ) {
				update_post_meta( $post_id, '_welearner_teacher_twitter_url', $twitter_url );
			}
        }

        if (isset($_POST['welearner_teacher_thumbnail_bg_color'])) {
			$thumb_bg_color = sanitize_text_field( $_POST['welearner_teacher_thumbnail_bg_color'] );
			if ( $thumb_bg_color ) {
				update_post_meta( $post_id, '_welearner_teacher_thumbnail_bg_color', $thumb_bg_color );
			}
        }
    }

    public function teacher_admin_scripts($hook_suffix) {
        $screen = get_current_screen();
        if( $hook_suffix != 'post.php' && $screen->post_type != 'teachers' ) {
            return;
        }
        wp_enqueue_style( 'wp-color-picker' );
        wp_enqueue_script( 'teacher-script', WELEARNERCORE_PLUGIN_URL . 'assets/js/teacher.js', array( 'wp-color-picker' ), false, true );
    }
}

$teacher = new Welearner_Teacher();