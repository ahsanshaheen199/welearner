(function($){
    $('.welearner_teacher_thumbnail_bg_color').wpColorPicker();
})(jQuery);