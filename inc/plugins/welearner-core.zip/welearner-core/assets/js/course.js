(function($){
    $('.course_topic_color').wpColorPicker();
    $('.course_topic_bg_color').wpColorPicker();

    //

    if( $("#course_topic_thumbnail_id").val() == 0 || ! $("#course_topic_thumbnail_id").val()  ) {
        $(".remove_course_topic_button").hide();
        console.log($("#course_topic_thumbnail_id").val());
    }


    var file_frame;

    $( document ).on( 'click', '.upload_course_topic_button', function( event ) {

        event.preventDefault();

        if ( file_frame ) {
            file_frame.open();
            return;
        }

        file_frame = wp.media({
            title: 'Choose an image',
            button: {
                text: 'Use image'
            },
            multiple: false
        });

        file_frame.on( 'select', function() {
            var attachment           = file_frame.state().get( 'selection' ).first().toJSON();
            var attachment_thumbnail = attachment.sizes.thumbnail || attachment.sizes.full;

            jQuery( '#course_topic_thumbnail_id' ).val( attachment.id );
            jQuery( '#course_topic_thumbnail' ).find( 'img' ).attr( 'src', attachment_thumbnail.url );
            jQuery( '.remove_course_topic_button' ).show();
        });

        file_frame.open();
    });


    jQuery( document ).on( 'click', '.remove_course_topic_button', function(event) {
        jQuery( '#course_topic_thumbnail' ).find( 'img' ).attr( 'src', 'https://place-hold.it/60x60/#e9e9e' );
        jQuery( '#course_topic_thumbnail_id' ).val( '' );
        jQuery( '.remove_course_topic_button' ).hide();
        event.preventDefault();
    });
})(jQuery);